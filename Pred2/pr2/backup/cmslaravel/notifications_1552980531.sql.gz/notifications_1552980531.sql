'7a73b821-1cdb-4158-8ff2-da2756ccc425', 'App\\Notifications\\Commented', '1', 'App\\Models\\User', '{\"title\":\"Post 1\",\"slug\":\"post-1\"}', '', '2017-02-07 08:57:25', '2017-02-07 08:57:25', 
'7b5a0445-8797-4eca-ac6b-16a9bf42d8ad', 'App\\Notifications\\Commented', '2', 'App\\Models\\User', '{\"title\":\"Post 4\",\"slug\":\"post-4\"}', '', '2017-02-07 09:13:12', '2017-02-07 09:13:12', 
