'1', 'Administrator', 'admin', '', '', 
'2', 'Redactor', 'redac', '', '', 
'3', 'User', 'user', '', '', 
