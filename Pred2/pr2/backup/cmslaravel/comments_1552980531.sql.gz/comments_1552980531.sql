'1', '', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torquatus, is qui consul cum Cn. Eadem nunc mea adversum te oratio est. Quid enim est a Chrysippo praetermissum in Stoicis? Ostendit pedes et pectus. Et ille ridens: Video, inquit, quid agas; Homines optimi non intellegunt totam rationem everti, si ita res se habeat. 

Quamquam tu hanc copiosiorem etiam soles dicere. Non est igitur summum malum dolor. Facile est hoc cernere in primis puerorum aetatulis. Sed in rebus apertissimis nimium longi sumus. Sed hoc sane concedamus. 

Duo Reges: constructio interrete. Conferam tecum, quam cuique verso rem subicias; Tubulo putas dicere? Ut nemo dubitet, eorum omnia officia quo spectare, quid sequi, quid fugere debeant? Perturbationes autem nulla naturae vi commoventur, omniaque ea sunt opiniones ac iudicia levitatis. Quod autem ratione actum est, id officium appellamus. Vos autem cum perspicuis dubia debeatis illustrare, dubiis perspicua conamini tollere. Ita enim vivunt quidam, ut eorum vita refellatur oratio. 

', '0', '2', '1', 
'2', '', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. An eiusdem modi? Atque hoc loco similitudines eas, quibus illi uti solent, dissimillimas proferebas. Iubet igitur nos Pythius Apollo noscere nosmet ipsos. At quicum ioca seria, ut dicitur, quicum arcana, quicum occulta omnia? 

Primum divisit ineleganter; Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; 

', '0', '2', '2', 
'3', '', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Itaque quantum adiit periculum! ad honestatem enim illum omnem conatum suum referebat, non ad voluptatem. Te ipsum, dignissimum maioribus tuis, voluptasne induxit, ut adolescentulus eriperes P. Nunc omni virtuti vitium contrario nomine opponitur. Nunc ita separantur, ut disiuncta sint, quo nihil potest esse perversius. Expectoque quid ad id, quod quaerebam, respondeas. Duo Reges: constructio interrete. At enim hic etiam dolore. Ego vero volo in virtute vim esse quam maximam; 

Quam nemo umquam voluptatem appellavit, appellat; Sed plane dicit quod intellegit. Si verbum sequimur, primum longius verbum praepositum quam bonum. Cur igitur, cum de re conveniat, non malumus usitate loqui? Quia dolori non voluptas contraria est, sed doloris privatio. Sic enim censent, oportunitatis esse beate vivere. Hunc vos beatum; Prodest, inquit, mihi eo esse animo. 

Itaque primos congressus copulationesque et consuetudinum instituendarum voluntates fieri propter voluptatem; Neque solum ea communia, verum etiam paria esse dixerunt. Murenam te accusante defenderem. Aperiendum est igitur, quid sit voluptas; Bona autem corporis huic sunt, quod posterius posui, similiora. Expressa vero in iis aetatibus, quae iam confirmatae sunt. Ut pulsi recurrant? Sed ad haec, nisi molestum est, habeo quae velim. 

', '0', '3', '1', 
'4', '2017-02-07 08:57:25', '2017-02-07 09:19:45', '<p>O ?emu vi to gospodo?</p>
', '1', '5', '1', 
