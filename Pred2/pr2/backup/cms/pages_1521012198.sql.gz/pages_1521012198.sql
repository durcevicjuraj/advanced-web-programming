'1', '2', 'Autorov post', 'Autor Vam želi reći...
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-03-01 10:36:13', '2017-01-27 21:35:07', 
'2', '2', 'Još jedan autorov post', 'Ovaj post mogu urediti autor i administrator.', '2017-02-25 20:38:47', '2017-01-28 21:35:07', 
'4', '3', 'Adminov post', 'Ovaj post može urediti samo administrator.', '2017-02-25 20:36:13', '2017-01-27 22:12:12', 
